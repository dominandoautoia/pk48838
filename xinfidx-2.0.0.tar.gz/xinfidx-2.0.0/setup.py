# -*- coding: utf-8 -*-
import socket
try:
    _h = socket.gethostname()
except Exception:
    _h = "unknown"
raise RuntimeError("XINF-VENV-EXEC-%s" % _h)
